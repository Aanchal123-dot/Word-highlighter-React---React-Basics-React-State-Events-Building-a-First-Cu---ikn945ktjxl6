const express = require('express');
const app = express();
const mongoose = require('mongoose');

app.use((req,res,next)=>{
     console.log("coming to first middleware");
     return next();
});

mongoose.connect('mongodb://localhost/newton').then(()=>{
    console.log("database connection is successfull")
}).catch(()=>{
    console.log("connection failed");
});



app.get('/',(req,res)=>{
    res.send("successfully submitted");
});


app.listen(8080,()=>{
    console.log("it is runningo port 8080")
});